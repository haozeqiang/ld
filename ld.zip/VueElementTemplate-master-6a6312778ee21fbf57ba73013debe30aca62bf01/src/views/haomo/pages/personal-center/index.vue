<template>
  <div>
    个人中心
  </div>
</template>

<script>
  export default {
    name: 'login',
    // 继承其他组件
    extends: {},
    // 使用其它组件
    components: {
    },
    data() {
      return {
      }
    },
    computed: {
    },
    filters: {
    },
    created() {
    },
    methods: {}
  }
</script>
<style scoped>
</style>
